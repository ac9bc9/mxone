<?php
namespace app\admin\controller;

class Xiao extends Base
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(){

        $config = parse_ini_file("./template/xiaozhuti/info.ini",true);
        $this->assign('config', $config);
        return $this->fetch('admin@xiao/index');
    }

    public function papa($star){

        if (Request()->isPost()) {
            $config = input();

            $validate = \think\Loader::validate('Token');
            if(!$validate->check($config)){
                return $this->error($validate->getError());
            }
            unset($config['__token__']);

            $config_new[$star] = $config[$star];
            $config_old = config('xiao');
            $config_new = array_merge($config_old, $config_new);

            $res = @fwrite(fopen('./static/js/tj.js', 'wb'), $config_new);

            $res = mac_arr2file(APP_PATH . 'extra/xiao.php', $config_new);
            if ($res === false) {
                return $this->error(lang('save_err'));
            }
            return $this->success(lang('save_ok'));
        }

        $config = config('xiao');
        $this->assign('config', $config);
        $this->assign('title', '小主题设置后台');
        return $this->fetch('admin@xiao/'.$star);

    }

    public function config(){
        return $this->papa('config');
    }

    public function web(){
        return $this->papa('web');
    }

    public function menu(){

        if (Request()->isPost()) {
            $config = input();

            $validate = \think\Loader::validate('Token');
            if(!$validate->check($config)){
                return $this->error($validate->getError());
            }
            unset($config['__token__']);

            $config_new['menu'] = $config['menu'];
            $config_old = config('xiao');
            $config_new = array_merge($config_old, $config_new);

            $res = mac_arr2file(APP_PATH . 'extra/xiao.php', $config_new);
            if ($res === false) {
                return $this->error('保存失败请检查传篡改是否拦截');
            }

            return $this->success(lang('save_ok'));
        }

        $ad = [1,2,3,4,5,6];
        $this->assign('ad', $ad);
        $this->assign('title', '小主题设置后台');
        $this->assign('config', config('xiao'));
        return $this->fetch('admin@xiao/menu');

    }

    public function personality(){

        if (Request()->isPost()) {
            $config = input();

            $validate = \think\Loader::validate('Token');
            if(!$validate->check($config)){
                return $this->error($validate->getError());
            }
            unset($config['__token__']);

            $config_new['gx'] = $config['gx'];
            $config_old = config('xiao');
            $config_new = array_merge($config_old, $config_new);

            $res = mac_arr2file(APP_PATH . 'extra/xiao.php', $config_new);
            if ($res === false) {
                return $this->error('保存失败请检查传篡改是否拦截');
            }

            return $this->success(lang('save_ok'));
        }

        $ad = [1,2,3,4,5,6];
        $this->assign('ad', $ad);
        $this->assign('title', '小主题设置后台');
        $this->assign('config', config('xiao'));
        return $this->fetch('admin@xiao/personality');

    }


    public function ad(){

        if (Request()->isPost()) {
            $config = input();

            $validate = \think\Loader::validate('Token');
            if(!$validate->check($config)){
                return $this->error($validate->getError());
            }
            unset($config['__token__']);

            $config_new['ad'] = $config['ad'];
            $config_old = config('xiao');
            $config_new = array_merge($config_old, $config_new);

            $res = mac_arr2file(APP_PATH . 'extra/xiao.php', $config_new);
            if ($res === false) {
                return $this->error('保存失败请检查传篡改是否拦截');
            }

            return $this->success(lang('save_ok'));
        }

        $ad = ['首页广告1','首页广告2','首页广告3','分类广告1','详情页横幅','我的主页背景（不用填链接）'];
        $this->assign('ad', $ad);
        $this->assign('title', '小主题设置后台');
        $this->assign('config', config('xiao'));
        return $this->fetch('admin@xiao/ad');

    }

}
