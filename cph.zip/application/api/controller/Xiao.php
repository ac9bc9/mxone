<?php
namespace app\api\controller;
use think\Controller;
use think\Cache;
use app\common\util\Pinyin;

class Xiao extends Base
{
    var $_param;

    public function __construct()
    {
        parent::__construct();
        $this->_param = input('','','trim,urldecode');
    }

    public function vod()
    {
        $param = mac_param_url();
        $page = intval($param['page']) <1 ? 1 : $param['page'];
        $limit = intval($param['limit']);
        if($page == 20){
            exit;
        }
        if($limit > 30){
            exit;
        }
        $order='vod_id desc';
        $where=[];
        if(!empty($param['type'])){
            $where['type_id|type_id_1'] = ['eq',$param['type']];
        }
        if(!empty($param['class'])){
            $where['vod_class'] = ['like',mac_like_arr($param['class']), 'OR'];
        }
        $field=['vod_name','vod_pic','vod_score','vod_id'];

        $res = model('Vod')->listData($where,$order,$page,$limit,0,$field);
        $ds = config('xiao');
        foreach ($res['list'] as $k => &$v) {
            $v['detail_link'] = mac_url_vod_detail($v);
            $v['vod_pic'] = mac_url_img($v['vod_pic']);
            $v['vod_pic_laz'] = mac_url_img($ds['web']['vod']['laz']);
            $v['target'] = $ds['web']['vod']['target'];
        }
        return json($res);
    }
}
