<?php
return array (
  'config' => 
  array (
    'logo' => 'template/xiaozhuti/img/logo.png',
    'logo2' => 'template/xiaozhuti/img/logo2.png',
    'icon' => 'template/xiaozhuti/img/ioc.png',
    'portrait' => 'template/xiaozhuti/img/portrait.png',
    'ma' => 'template/xiaozhuti/img/ma.jpg',
    'vod_type' => '1,2,3,4,13',
    'app_url' => 'https://www.ezhuti.com/',
  ),
  'web' => 
  array (
    'so' => 
    array (
      'txt' => '电影、剧集、综艺、动漫……',
    ),
    'tab' => 
    array (
      'off1' => 'on',
      'name1' => '好物',
      'cion1' => 'icon-gouwudai',
      'url1' => '#',
      'off2' => 'on',
      'name2' => '赞助',
      'cion2' => 'icon-shandian1',
      'url2' => '#',
    ),
    'index' => 
    array (
      'slide' => '1',
    ),
    'vod' => 
    array (
      'target' => '0',
      'copyright' => '0',
      'txt' => '应版权方要求该资源已下架',
      'comment' => '0',
      'laz' => 'template/xiaozhuti/img/img-bj-k.png',
    ),
  ),
  'ad' => 
  array (
    0 => 
    array (
      'name' => '购物不能每卷',
      'url' => '#',
      'img' => 'template/xiaozhuti/img/ad1.png',
    ),
    1 => 
    array (
      'name' => '给傻冒茶虎充电',
      'url' => '#',
      'img' => 'template/xiaozhuti/img/ad2.png',
    ),
    2 => 
    array (
      'name' => '购物没有卷来这里找啊',
      'url' => '#',
      'img' => 'template/xiaozhuti/img/ad3.png',
    ),
    3 => 
    array (
      'name' => '赞助茶壶大傻吊',
      'url' => '#',
      'img' => 'template/xiaozhuti/img/ad4.png',
    ),
    4 => 
    array (
      'name' => '恒星播放器茶壶推荐指定垃圾',
      'url' => '#',
      'img' => 'template/xiaozhuti/img/ad5.png',
    ),
    5 => 
    array (
      'name' => '',
      'url' => '',
      'img' => 'template/xiaozhuti/img/ad11.png',
    ),
  ),
  'menu' => 
  array (
    'index' => 
    array (
      0 => 
      array (
        'name' => '电影',
        'icon' => 'template/xiaozhuti/img/type7.png',
        'url' => '/index.php/vod/type/id/1.html',
      ),
      1 => 
      array (
        'name' => '电视剧',
        'icon' => 'template/xiaozhuti/img/type6.png',
        'url' => '/index.php/vod/type/id/2.html',
      ),
      2 => 
      array (
        'name' => '综艺',
        'icon' => 'template/xiaozhuti/img/type3.png',
        'url' => '/index.php/vod/type/id/4.html',
      ),
      3 => 
      array (
        'name' => '动漫',
        'icon' => 'template/xiaozhuti/img/type4.png',
        'url' => '/index.php/vod/type/id/3.html',
      ),
      4 => 
      array (
        'name' => '纪录片',
        'icon' => 'template/xiaozhuti/img/type2.png',
        'url' => '/index.php/vod/type/id/5.html',
      ),
      5 => 
      array (
        'name' => '筛选',
        'icon' => 'template/xiaozhuti/img/type1.png',
        'url' => '/index.php/vod/show/id/1.html',
      ),
    ),
  ),
  'gx' => 
  array (
    'style' => 'bai',
  ),
);